module FontAwesome
  module Sass
    VERSION = "6.1.1".freeze
  end
end
